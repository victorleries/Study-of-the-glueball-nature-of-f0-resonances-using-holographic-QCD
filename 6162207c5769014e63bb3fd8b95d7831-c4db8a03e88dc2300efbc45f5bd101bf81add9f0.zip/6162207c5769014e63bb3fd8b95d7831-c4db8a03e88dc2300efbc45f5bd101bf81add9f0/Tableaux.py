import copy

##########################################################################################################################################
################################################################  README  ################################################################
##########################################################################################################################################
## Small python script to calculate products of Young Tableaux                                                                          ##
## Author: Lars Bündgen                                                                                                                 ##
##########################################################################################################################################
## Import:                                                                                                                              ##
##   from Tableaux import *                                                                                                             ##
## Young tableaux are represented by instances of the class YoungTableau.                                                               ##
## creating tableaux:                                                                                                                   ##
##   fund(n) is the fundamental representation of SU(n)                                                                                 ##
##   anti(n) is the antifundamental representation of SU(n)                                                                             ##
##   adj(n) is the adjoint representation of SU(n)                                                                                      ##
##   sing(n) is the singlet representation of SU(n)                                                                                     ##
##   from_part(n, partition) creates a tableau in SU(n) from an integer partition, like from_part(3, [2, 1]) for the [2, 1] of SU(3)    ##
## display information:                                                                                                                 ##
##   show(t) on a tableau t or a list of tableaux t to show details                                                                     ##
##   show_unique(t) on a tableau t or a list of tableaux t to show details, grouped ber unique tableau                                  ##
##   dim(t)  on a tableau t or a list of tableaux t to show the representation dimension                                                ##
## multiplication:                                                                                                                      ##
##   prod(*t) to calculate the product of two or more tableaux and return the result as a list                                          ##
##   prod_print(*t) to calculate the product with step-by-step output                                                                   ##
##   the multiplication operator * is supported by the YoungTableau class                                                               ##
##########################################################################################################################################
## Example: multiply SU(3) fundamental and antifundamental:                                                                             ##
##   show( fund(3) * anti(3) )                                                                                                          ##
## Example: multiply SU(3) [2,1] x [2,1] x [2,1]                                                                                        ##
##   x = from_part(3, [2, 1])                                                                                                           ##
##   show(x * x * x)                                                                                                                    ##
## Example: Step-by-step calculation for SU(3) [3,1] x [3,1]                                                                            ##
##   x = from_part(3, [3, 1])                                                                                                           ##
##   prod_print(x, x)                                                                                                                   ##
##########################################################################################################################################
##########################################################################################################################################

#singlet not allowed
def validate_integer_partition(dimension, *args):
    if len(args) >= dimension:
        return False
    last = None
    for i in args:
        if last and last < i:
            return False
    return True

def validate_admissible_sequence(*sequence, start_char='a'):
    counts = dict()
    #assume that the labels are ordered as in ascii
    
    for c in sequence:
        #add to dict
        if c not in counts:
            counts[c] = 1
        else:
            counts[c] = counts[c] + 1
        #the check
        if c != start_char:
            p = chr(ord(c) - 1)
            if p not in counts or counts[p] < counts[c]:
                return False
    return True
    

#Store data as array of arrays to support labels in cells:
# [(a, a, a),
#  (b, b),
#  (c)]
class YoungTableau:
    def __init__(self, dimension, *, partition=None, dynkin=None, cells=None):
        if dimension <= 1:
            raise ValueError("Dimension has to be at least two")
        self.__dim = dimension
        ok = False
        
        if partition is not None:    
            if not validate_integer_partition(dimension, *partition):
                raise ValueError("Not a valid integer partition")
            self.__cells = [[' ' for i in range(row)] for row in partition]
            ok = True
        if dynkin is not None:
            if ok:
                raise ValueError("Cannot pass two different representations of the tableau")
            raise ValueError("create from dynkin is not implemented")
            ok = True
        if cells is not None:
            if ok:
                raise ValueError("Cannot pass two different representations of the tableau")
            self.__cells = copy.deepcopy(cells)
            if not validate_integer_partition(dimension, self.get_partition()):
                raise ValueError("Invalid cell configuration")
            ok = True
        if not ok:
            raise ValueError("Tableau has to be initialized")
    
    def __mul__(self, other):
        #implement distributive rule
        if isinstance(other, YoungTableau):
            return product2(self, other, print=no_print)
        else:
            r = []
            for t in other:
                r += product2(self, t, print=no_print)
            return r
            
    def __rmul__(self, other):
        #implement distributive rule
        if isinstance(other, YoungTableau):
            return product2(other, self, print=no_print)
        else:
            r = []
            for t in other:
                r += product2(t, self, print=no_print)
            return r
    
    def get_partition(self):
        return [len(row) for row in self.__cells]
    
    def get_cells(self):
        return copy.deepcopy(self.__cells)

    def get_dynkin(self):
        p1 = self.get_partition()
        if not p1:
            return []
        p2 = list(p1) # copy
        p2.pop(0)
        p2.append(0)
        return [a - b for (a, b) in zip(p1, p2)]
    
    def copy(self):
        return YoungTableau(self.__dim, cells=self.__cells)

    def copy_clean(self):
        t = self.copy()
        t.clear_labels()
        t.clear_singlets()
        return t
    
    def get_dimension(self):
        return self.__dim
    
    def get_column_partition(self):
        row_sizes = self.get_partition()
        if not row_sizes:
            return []
        col_sizes = [0] * row_sizes[0]
        
        for rs in row_sizes:
            #row is rs long
            #increment the first rs cols:
            for c in range(rs):
                col_sizes[c] = col_sizes[c] + 1
        return col_sizes
    
    def get_representation_dimension(self):
        hooks = []
        nums = []
        row_sizes = self.get_partition()
        col_sizes = self.get_column_partition()
        
        for r in range(len(row_sizes)):
            for c in range(row_sizes[r]):
                hooks.append(row_sizes[r] - c + col_sizes[c] - r - 1)
                nums.append(self.__dim + c - r)
            
        def prod(l):
            r = 1
            for x in l:
                r *= x
            return r
        N = prod(nums)
        D = prod(hooks)
        return int(N / D)
        
    
    def get_boxes(self):
        return [box for row in self.__cells for box in row]
    
    def apply_labels(self, *chars):
        if not chars:
            chars = [chr(ord('a') + i) for i in range(self.__dim)]
        else:
            if len(chars) < self.__dim - 1:
                raise ValueError("Not enough characters")
        for (row, c) in zip(self.__cells, chars):
            for i in range(len(row)):
                row[i] = c
    
    def clear_labels(self):
        self.__cells = [[' ' for i in row] for row in self.__cells]
    
    def print_tableau(self, *, print=print):
        if not self.__cells:
            print("<singlet>")
        for row in self.__cells:
            print("[", sep="", end="")
            print(*row, sep="][", end="]\n")
            
    def print_all(self, *, print=print):
        print(f"Young Tabeau in SU({self.__dim}) of dimension {self.get_representation_dimension()}")
        print(f"Partition: {list(self.get_partition())}")  #trick it into printint the [] with list
        print(f"Dynkin label: {tuple(self.get_dynkin())}") #trick it into printint the () with tuple
        self.print_tableau(print=print)
        print()
    
    def __hash__(self):
        return 0 #bad, but okay
        
    def get_sequence(self):
        #iterate row by row, right to left
        seq = []
        for row in self.__cells:
            for box in reversed(row):
                if box != ' ':
                    seq.append(box)
        return seq
    
    #TODO test this
    def clear_singlets(self):
        if len(self.__cells) < self.__dim:
            return
        singlets = self.get_partition()[-1]
        rmd = [row[singlets:None] for row in self.__cells]
        while rmd and not rmd[-1]:
            rmd.pop()
        self.__cells = rmd
        
    def has_identical_vertical(self): #checks for two vertically adjacent boxes with the same label
        #for every box, check the one below
        n = len(self.__cells)
        for r in range(n):
            l = len(self.__cells[r])
            for c in range(l):
                box = self.__cells[r][c]
                #if row below exists AND has as many elements
                if r < n-1 and len(self.__cells[r+1]) > c:
                    below = self.__cells[r+1][c]
                    if below != ' ' and box != ' ' and below == box:
                        return True
        return False
    
    def try_append_box(self, box, row):
        if row >= self.__dim:
            return False
            
        if row == len(self.__cells):
            self.__cells.append([box])
        elif row > len(self.__cells):
            return False
        elif row == 0: #just do it
            self.__cells[0].append(box)
        else:
            above = self.__cells[row - 1]
            here = self.__cells[row]
            if len(above) <= len(here):
                return False
            else:
                self.__cells[row].append(box)
        return True
    
    def __eq__(self, other):
        return self.__dim == other.__dim and self.__cells == other.__cells
    
def product2(tab1, tab2, print=print):
    if tab1.get_dimension() != tab2.get_dimension():
        raise ValueError("Dimensions must match")
    
    tab1 = tab1.copy_clean()
    tab2 = tab2.copy_clean()
    tab2.apply_labels()
    print("###############################################")
    print("Multiplying tableaux")
    tab1.print_all(print=print)
    print("times")
    tab2.print_all(print=print)
    print()
    
    
    print("###############################################")
    print("Applying labeled boxes to the first tableau")
    print()
    tbs = [tab1]
    for row in tab2.get_cells():
        for box in row: #outer two loops do the boxes
            #always apply to all current tableaux
            print()
            print("###############################################")
            print(f"Applying box {box} to {len(tbs)} tableaux")
            tbsn = []
            for tb in tbs:
                print()
                print(f"Applying box [{box}] to")
                tb.print_tableau(print=print)
                #try every position
                for i in range(tb.get_dimension()):
                    tbn = tb.copy()
                    if tbn.try_append_box(box, i) and not tbn.has_identical_vertical():
                        print("Successfully applied box:")
                        tbn.print_tableau(print=print)
                        tbsn.append(tbn)
                    #else don't put it in this row
                #all rows done
            #all tableaux used
            #make sure to only copy back the unique ones
            tbs = list(set(tbsn))
    #all boxes are applied, eliminate stuff using the sequences
    print("###############################################")
    print(f"Checking admissible sequences ({len(tbs)} tableaux)")
    print()
    
    tbsa = []
    
    for t in tbs:
        print()
        print("Diagram")
        t.print_tableau(print=print)
        seq = t.get_sequence();
        print(f"has sequence ", *seq, sep='')
        if validate_admissible_sequence(*seq):
            print("This is admissible")
            tbsa.append(t.copy())
        else:
            print("This is not admissible")
    
    #now tbsa has result:
    print("###############################################")
    print(f"Calculation result has {len(tbsa)} terms")
    print()
    for t in tbsa:
        t.clear_singlets()
        t.clear_labels()
        t.print_all(print=print)
    
    print(f"Sum of dimensions: {dim(tbsa)}")
    
    return tbsa
    
def product(*diagrams, print=print):
    if len(diagrams) == 0: 
        raise ValueError("Empty list")
    elif len(diagrams) == 1:
        print("Trivial case: only one factor")
        t = diagrams[0].copy_clean()
        t.print_all(print=print)
        print()
        return t
    elif len(diagrams) == 2:
        print("Simple case: only two factors")
        rr = product2(diagrams[0], diagrams[1], print=print)
        return rr
    else:
        print(f"Complex case: {len(diagrams)} factors (use distributive/associative property)")
        print("Steps will not be printed")
        print("Multiplying first two tableaux:")
        t1 = diagrams[0].copy_clean()
        t2 = diagrams[1].copy_clean()
        t1.print_tableau(print=print)
        print("times")
        t2.print_tableau(print=print)
        res = product2(diagrams[0], diagrams[1], print=print)
        print(f"Result: {len(result)} tableaux:")
        for t in res:
            t.print_tableau(print=print)
        
        print("###############################################")
        print("Recursively multiplying every term with the remaining factors")
        r = []
        for t in res:
            rr = product(r, *diagrams[2:None], print=print)
            r += rr
        return rr

def no_print(*args, **kwargs):
    pass

def fundamental(dimension):
    if dimension <= 1:
        raise ValueError("Dimension must be at least 2")
    return YoungTableau(dimension, partition=[1])
    
def antifundamental(dimension):
    if dimension <= 1:
        raise ValueError("Dimension must be at least 2")
    p = [1] * (dimension - 1)
    return YoungTableau(dimension, partition=p)

def adjoint(dimension):
    if dimension <= 1:
        raise ValueError("Dimension must be at least 2")
    p = [1] * (dimension - 1)
    p[0] = 2
    return YoungTableau(dimension, partition=p)
    
def singlet(dimension):
    if dimension <= 1:
        raise ValueError("Dimension must be at least 2")
    return YoungTableau(dimension, partition=[])

def representation_dimension(r):
    if isinstance(r, YoungTableau):
        return r.get_representation_dimension()
    else:
        d = 0
        for t in r:
            d += t.get_representation_dimension()
        return d

def fund(n):
    return fundamental(n)

def anti(n):
    return antifundamental(n)
    
def adj(n):
    return adjoint(n)
    
def sing(n):
    return singlet(n)
    
def from_part(n, part):
    return YoungTableau(n, partition=part)
    
def from_cells(n, cells):
    return YoungTableau(n, cells=cells)
    
def from_dynkin(n, dynkin):
    return YoungTableau(n, dynkin=dynkin)
    
def prod(*t):
    return product(*t, print=no_print)

def prod_print(*t):
    return product(*t, print=print)

def show(r):
    if isinstance(r, YoungTableau):
        r.print_all()
    else:
        print(f"Summary for {len(r)} tableaux:")
        d = 0
        for t in r:
            t.print_all()
            d += t.get_representation_dimension()
        print(f"Sum of dimensions: {d}")    

def show_unique(r):
    if isinstance(r, YoungTableau):
        r.print_all()
    else:
        d = 0
        unique = list(set(r))
        for u in unique:
            c = r.count(u)
            print(f"Occurs {c} times: ")
            u.print_all()
            d += c * u.get_representation_dimension()
        print(f"Sum of dimensions: {d}")    

def dim(y):
    return representation_dimension(y)
    
    
if __name__ == "__main__":
    print("Program for automated Young Tableau multiplication")
    print("Open the python file in a text editor to find a short readme section")
    print("Can be used in a python script or in an interactive python session")
    print("Currently does not support direct CLI input")
    print("Press Enter to exit")
    input()